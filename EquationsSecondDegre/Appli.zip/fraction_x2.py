from tkinter import *
import matplotlib.pyplot as plt
import numpy as np
import __main__

def x2_frac(a_num,a_denom,b_num,b_denom,delta_num,delta_denom):
    print('racine 2')
