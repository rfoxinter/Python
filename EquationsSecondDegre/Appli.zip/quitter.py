import __main__

def main_quit():
    __main__.plt.close()
    __main__.Fen.destroy()
