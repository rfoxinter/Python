def jours(start,end,format='dd/mm/yyyy'):
    from . import _diff
    start=[int(i) for i in start.split('/')]
    end=[int(i) for i in end.split('/')]
    format=format.lower()
    f=format
    f=f.split('/')
    start=[start[f.index('dd')],start[f.index('mm')],start[f.index('yyyy')]]
    end=[end[f.index('dd')],end[f.index('mm')],end[f.index('yyyy')]]
    del f
    if not (1<=start[1]<=12 and 1<=end[1]<=12):
        raise ValueError('jour(start,end,format=\''+format+'\') → 1<=mm<=12')
    if not 1<=start[0]<=_diff.jours_mois(start):
        raise ValueError('jour(start,end,format=\''+format+'\') → start : 1<=dd<='+str(_diff.jours_mois(start)))
    if not 1<=end[0]<=_diff.jours_mois(end):
        raise ValueError('jour(start,end,format=\''+format+'\') →  end : 1<=dd<='+str(_diff.jours_mois(end)))
    diff_annees=end[2]-start[2]-1
    bissextiles=end[2]//4-(start[2]+1+(4-(start[2]+1)%4)%4)//4-end[2]//100+(start[2]+1+(100-(start[2]+1)%100)%100)//100+end[2]//400-(start[2]+1+(400-(start[2]+1)%400)%400)//400
    if end[2]//4-(start[2]+1+(4-(start[2]+1)%4)%4)//4<0:
        bissextiles+=1
    if end[2]//100-(start[2]+1+(100-(start[2]+1)%100)%100)//100<0:
        bissextiles-=1
    if end[2]//400-(start[2]+1+(400-(start[2]+1)%400)%400)//400<0:
        bissextiles+=1
    return bissextiles*366+(diff_annees-bissextiles)*365+_diff.diff_debut(start)+_diff.diff_fin(end)