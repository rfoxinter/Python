def jours_mois(date):
    i=date[1]
    if i==2:
        if date[2]%400==0 or date[2]%4==0 and date[2]%100!=0:
            return 29
        else:
            return 28
    elif i>7 and i%2==0:
        return 31
    elif i<8 and i%2==1:
        return 31
    else:
        return 30

def diff_debut(date):
    jours=0
    i=12
    while i>=date[1]:
        if i==2:
            if date[2]%400==0 or date[2]%4==0 and date[2]%100!=0:
                jours+=29
            else:
                jours+=28
        elif i>7 and i%2==0:
            jours+=31
        elif i<8 and i%2==1:
            jours+=31
        else:
            jours+=30
        i-=1
    jours-=date[0]
    return jours

def diff_fin(date):
    jours=0
    i=1
    while i<date[1]:
        if i==2:
            if date[2]%400==0 or date[2]%4==0 and date[2]%100!=0:
                jours+=29
            else:
                jours+=28
        elif i>7 and i%2==0:
            jours+=31
        elif i<8 and i%2==1:
            jours+=31
        else:
            jours+=30
        i+=1
    jours+=date[0]
    return jours