from . import conversion
from . import dates
from . import sec_deg
from . import trigo

def exp(x):
    from . import _calc_exp
    exp=_calc_exp.exp(1)**x
    if exp>1e10:
        exp=str(exp)
        ex=''
        for i in range(11):
            ex=ex+exp[i]
        if int(exp[12])>=5:
            ex=ex+str(int(exp[11])+1)
        else:
            ex=ex+exp[11]
        for i in range(len(exp)):
            if exp[i]=='e':
                ex=ex+exp[i:len(exp)]
        return round(float(ex),10)
    else:
        return round(exp,10)

def fibo(n):
    if n!=int(n):
        raise ValueError('fibo(n) → n doit être un entier')
    if n<0:
        raise ValueError('fibo(n) → n doit être supérieur ou égal à 0')
    fibo_n=0
    a,b=0,1
    for i in range(n):
        fibo_n=a
        a,b=b,a+b
    return fibo_n

def fibo_suite(n):
    if n!=int(n):
        raise ValueError('fibo_suite(n) → n doit être un entier')
    if n<0:
        raise ValueError('fibo_suite(n) → n doit être supérieur ou égal à 0')
    fibo=[]
    a=0
    b=1
    for i in range(n):
        fibo.append(a)
        a,b=b,a+b
    return fibo

def ln(x):
    if x<=0:
        raise ValueError('ln(x) → x doit être strictement supérieur à 0')
    from . import _calc_ln
    return _calc_ln.ln(x)

def log(x,base=10):
    if x<=0:
        raise ValueError('log(x) → x doit être strictement supérieur à 0')
    from . import _calc_ln
    return round(_calc_ln.ln(x,True)/_calc_ln.ln(base,True),10)

def e_val():
    from . import _calc_exp
    return round(_calc_exp.exp(1),15)
global e
e=e_val()
del e_val

def pi_val():
    from . import _calc_pi
    return _calc_pi.pi()
global pi
pi=pi_val()
del pi_val