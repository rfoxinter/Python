def arccos(x):
    from . import _calc_arcsin
    if abs(x)>1:
        return 'Erreur'
    else:
        return round(pi/2-_calc_arcsin.arcsin(x,True),10)

def arcosh(x):
    from . import _calc_ln
    if x<1:
        return 'Erreur'
    else:
        return  _calc_ln.ln(x+(x**2-1)**0.5)

def arcoth(x):
    if abs(x)<=1:
        return 'Erreur'
    from .. import _calc_ln
    return round(_calc_ln.ln((x-1)/(X+1))/2,10)

def arccot(x):
    from . import _calc_arcsin
    return round(pi/2-_calc_arcsin.arcsin(x/((x**2+1)**0.5),True),10)

def arccrd(x):
    from . import _calc_arcsin
    return round(2*_calc_arcsin.arcsin(x/2,True),10)

def arccsc(x):
    from . import _calc_arcsin
    if abs(x)<1:
        return 'Erreur'
    else:
        return round(_calc_arcsin.arcsin(1/x,True),10)

def arcexsec(x):
    from . import _calc_arcsin
    return round(pi/2-_calc_arcsin.arcsin(1/(x+1),True),10)

def arcsch(x):
    if x==0:
        return 'Erreur'
    from .. import _calc_ln
    return _calc_ln.ln(1/x+(1/x**2+1)**0.5)

def arcsec(x):
    from . import _calc_arcsin
    if abs(x)<1:
        return 'Erreur'
    else:
        return round(pi/2-_calc_arcsin.arcsin(1/x,True),10)

def arcsin(x):
    from . import _calc_arcsin
    return _calc_arcsin.arcsin(x)

def arctan(x):
    from . import _calc_arcsin
    return round(_calc_arcsin.arcsin(x/((x**2+1)**0.5),True),10)

def arsech(x):
    if x<=0 or x>1:
        return 'Erreur'
    from .. import _calc_ln
    return _calc_ln.ln(1/x+(1/x**2-1)**0.5)

def arsinh(x):
    from .. import _calc_ln
    return _calc_ln.ln(x+(x**2+1)**0.5)

def artanh(x):
    if abs(x)>=1:
        return 'Erreur'
    from .. import _calc_ln
    return round(_calc_ln.ln((x+1)/(X-1))/2,10)

def cos(x):
    from . import _calc_cos
    return _calc_cos.cos(x)

def cosh(x):
    from . import __calc_cosh
    return __calc_cosh.cosh(x)

def cot(x):
    from . import _calc_sin
    sin=_calc_sin.sin(x,True)
    if round(sin,10)==0:
        return 'Erreur'
    from . import _calc_cos
    cos=_calc_cos.cos(x,True)
    cot=cos/sin
    if round(cot,10)==-round(cot,10) and cot<0:
        cot=-cot
    return round(cot,10)

def coth(x):
    from . import __calc_sinh
    sinh=__calc_sinh.sinh(x,True)
    if round(sinh,10)==0:
        return 'Erreur'
    from . import __calc_cosh
    cosh=__calc_cosh.cosh(x,True)
    coth=cosh/sinh
    if round(coth,10)==-round(coth,10) and coth<0:
        coth=-coth
    return round(coth,10)

def crd(x):
    from . import _calc_sin
    return round(2*_calc_sin.sin(x/2,True),10)

def csc(x):
    from . import _calc_sin
    sin=_calc_sin.sin(x,True)
    if round(sin,10)==0:
        return 'Erreur'
    else:
        return round(1/sin,10)

def csch(x):
    from . import __calc_sinh
    sinh=__calc_sinh.sinh(x,True)
    if round(sinh,10)==0:
        return 'Erreur'
    else:
        return round(1/sinh,10)

def cvc(x):
    from . import _calc_sin
    return round(1+_calc_sin.sin(x,True),10)

def cvs(x):
    from . import _calc_sin
    return round(1-_calc_sin.sin(x,True),10)

def excsc(x):
    from . import _calc_cos
    cos=_calc_cos.cos(x)
    if round(cos,10)==0:
        return 'Erreur'
    exsec=(1-cos)/cos
    return round(exsec,10)

def exsec(x):
    from . import _calc_cos
    cos=_calc_cos.cos(x)
    if round(cos,10)==0:
        return 'Erreur'
    exsec=(1-cos)/cos
    return round(exsec,10)

def sec(x):
    from . import _calc_cos
    cos=_calc_cos.cos(x,True)
    if round(cos,10)==0:
        return 'Erreur'
    else:
        return round(1/cos,10)

def sech(x):
    from . import __calc_cosh
    cosh=_calc_cos.cosh(x,True)
    if round(cosh,10)==0:
        return 'Erreur'
    else:
        return round(1/cosh,10)

def sin(x):
    from . import _calc_sin
    return _calc_sin.sin(x)

def sinh(x):
    from . import __calc_sinh
    return __calc_sinh.sinh(x)

def tan(x):
    from . import _calc_cos
    cos=_calc_cos.cos(x,True)
    if round(cos,10)==0:
        return 'Erreur'
    from . import _calc_sin
    sin=_calc_sin.sin(x,True)
    tan=sin/cos
    if round(tan,10)==-round(tan,10) and tan<0:
        tan=-tan
    return round(tan,10)

def tanh(x):
    from . import __calc_cosh
    cosh=__calc_cosh.cosh(x,True)
    if round(cosh,10)==0:
        return 'Erreur'
    from . import __calc_sinh
    sinh=__calc_sinh.sinh(x,True)
    tanh=sinh/cosh
    if round(tanh,10)==-round(tanh,10) and tanh<0:
        tanh=-tanh
    return round(tanh,10)

def vcs(x):
    from . import _calc_cos
    return round(1+_calc_cos.cos(x,True),10)

def versin(x):
    from . import _calc_cos
    return round(1-_calc_cos.cos(x,True),10)

def pi_val():
    from .. import _calc_pi
    return _calc_pi.pi()
global pi
pi=pi_val()
del pi_val