def cosh(x,call=False):
    cosh=1.0
    i=1
    F=1
    suite=1.0
    while abs(suite)>1E-15:
        F=F*(2*i-1)
        F=F*2*i
        suite=((x**(2*i))/F)
        cosh+=suite
        i=i+1
    if round(cosh,10)==-round(cosh,10) and cosh<0:
        cosh=-cosh
    if call:
        return cosh
    else:
        return round(cosh,10)