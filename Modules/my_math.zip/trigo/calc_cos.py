def cos(x,call=False):
    cos=1
    i=1
    F=1
    suite=1.0
    while abs(suite)>1e-15:
        F=F*(2*i-1)
        F=F*(2*i)
        suite=(((-1)**i)/F)*(x**(2*i))
        cos+=suite
        i=i+1
    if round(cos,10)==-round(cos,10) and cos<0:
        cos=-cos
    if call:
        return cos
    else:
        return round(cos,10)