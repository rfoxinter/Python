def sinh(x,call=False):
    sinh=float(x)
    i=1
    F=1
    suite=1.0
    while abs(suite)>1E-15:
        F=F*(2*i)
        F=F*(2*i+1)
        suite=((x**(2*i+1))/F)
        sinh+=suite
        i=i+1
    if round(sinh,10)==-round(sinh,10) and sinh<0:
        sinh=-sinh
    if call:
        return sinh
    else:
        return round(sinh,10)