def sin(x,call=False):
    sin=float(x)
    i=1
    F=1
    suite=1.0
    while abs(suite)>1e-15:
        F=F*(2*i)
        F=F*(2*i+1)
        suite=((-1)**i)*((x**(2*i+1))/F)
        sin+=suite
        i=i+1
    if round(sin,10)==-round(sin,10) and sin<0:
        sin=-sin
    if call:
        return sin
    else:
        return round(sin,10)