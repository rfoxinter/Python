def arcsin(x,call=False):
    if x>-1 and x<1:
        val_x=x
        arcsin=float(x)
        suite=1.0
    elif abs(x)==1:
        arcsin=x*1.570796326794897
        suite=0.0
    elif call:
        val_x=1/x
        arcsin=float(1/x)
        suite=1.0
    else:
        return 'Erreur'
    i=1
    F_n=1
    F_d=1
    while abs(suite)>1e-15:
        F_n=F_n*(2*i-1)
        F_n=F_n*(2*i)
        F_d=F_d*i
        suite=(F_n/((F_d*2**i)**2))*((val_x**(2*i+1))/(2*i+1))
        arcsin+=suite
        i+=1
    if call:
        return arcsin
    else:
        return round(arcsin,10)