def kilometre_metre(x):
    return 1000*x
def pied_metre(x):
    return 3.048/10*x
def pouce_metre(x):
    return 2.54/100*x
def metre_metre(x):
    return x
def metre_kilometre(x):
    return x/1000
def metre_pied(x):
    return 10/3.048*x
def metre_pouce(x):
    return 100/2.54*x

def main(_in,_out,x):
    x=globals()['%s_%s'%(_in,'metre')](x)
    return globals()['%s_%s'%('metre',_out)](x)