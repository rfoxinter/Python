def degre_kelvin(x):
    return x+273.15
def fahrenheit_kelvin(x):
    return (5/9)*x-(160/9)+273.15
def rankine_kelvin(x):
    return x/1.8
def reaumur_kelvin(x):
    return 1.25*x+273.15
def kelvin_kelvin(x):
    return x
def kelvin_degre(x):
    return x-273.15
def kelvin_fahrenheit(x):
    return (9/5)*(x-273.15)+32
def kelvin_rankine(x):
    return 1.8*x
def kelvin_reaumur(x):
    return 0.8*x-218.52

def main(_in,_out,x):
    x=globals()['%s_%s'%(_in,'kelvin')](x)
    return globals()['%s_%s'%('kelvin',_out)](x)