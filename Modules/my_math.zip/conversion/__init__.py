def longueur(_in,_out,x):
    valeurs=('metre','pied','pouce')
    if _in.lower() not in valeurs:
        raise ValueError('longueur(_in,_out,x) → _in doit être une de ces unités : '+str(valeurs))
    if _out.lower() not in valeurs:
        raise ValueError('longueur(_in,_out,x) → _out doit être une de ces unités : '+str(valeurs))
    from . import _longueur
    return _longueur.main(_in.lower(),_out.lower(),x)

def temperature(_in,_out,x):
    valeurs=('degre','fahrenheit','kelvin','rankine','reaumur')
    if _in.lower() not in valeurs:
        raise ValueError('temperature(_in,_out,x) → _in doit être une de ces unités : '+str(valeurs))
    if _out.lower() not in valeurs:
        raise ValueError('temperature(_in,_out,x) → _out doit être une de ces unités : '+str(valeurs))
    from . import _temperature
    return _temperature.main(_in.lower(),_out.lower(),x)