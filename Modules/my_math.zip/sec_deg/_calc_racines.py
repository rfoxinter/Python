def racines(a,b=0,c=0):
    delta=b**2-4*a*c
    if delta<0:
        return 'Pas de racine'
    elif delta==0:
        return -b/2*a
    else:
        return ((-b-(b**2-4*a*c)**0.5)/2*a,(-b+(b**2-4*a*c)**0.5)/2*a)