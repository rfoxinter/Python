def alpha(a,b=0,c=0):
    return -b/2*a