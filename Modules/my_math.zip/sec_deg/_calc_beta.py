def beta(a,b=0,c=0):
    return (-b**2+4*a*c)/4*a