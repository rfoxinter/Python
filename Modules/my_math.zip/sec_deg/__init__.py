def alpha(a,b=0,c=0):
    if a==0:
        raise ValueError('alpha(a,b,c) → a doit être différent de 0')
    from . import _calc_alpha
    return _calc_alpha.alpha(a,b,c)

def beta(a,b=0,c=0):
    if a==0:
        raise ValueError('beta(a,b,c) → a doit être différent de 0')
    from . import _calc_beta
    return _calc_beta.beta(a,b,c)

def delta(a,b=0,c=0):
    if a==0:
        raise ValueError('delta(a,b,c) → a doit être différent de 0')
    from . import _calc_delta
    return _calc_delta.delta(a,b,c)

def racines(a,b=0,c=0):
    if a==0:
        raise ValueError('racines(a,b,c) → a doit être différent de 0')
    from . import _calc_racines
    return _calc_racines.racines(a,b,c)