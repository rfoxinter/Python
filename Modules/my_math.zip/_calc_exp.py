def exp(x):
    e=1.0
    i=1
    F=1
    suite=1.0
    while abs(suite)>1e-15:
        F=F*i
        suite=(x**i)/(F)
        e+=suite
        i+=1
    return e