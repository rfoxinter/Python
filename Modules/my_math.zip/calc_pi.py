def pi():
    pi = 0.0
    for k in range(10000):
        pi+=(16**(-k))*(4/(8*k+1)-(2/(8*k+4))-(1/(8*k+5))-(1/(8*k+6)))
    return float("{:.15f}".format(pi))