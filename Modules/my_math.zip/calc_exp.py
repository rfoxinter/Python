def exp(x,call=False):
    e=1.0
    i=1
    F=1
    suite=1.0
    while abs(suite)>1e-15:
        F=F*i
        suite=(x**i)/(F)
        e+=suite
        i+=1
    if call:
        return e
    else:
        return round(e,10)
