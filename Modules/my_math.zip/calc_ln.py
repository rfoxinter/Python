def ln(x,call=False):
    if x<=0:
        return 'Error'
    elif x>1:
        val_x=1/x-1
        k=-1
    else:
        val_x=x-1
        k=1
    ln=0.0
    i=1
    suite=1.0
    while abs(suite)>1e-15:
        suite=((-val_x)**i)/(i)
        ln-=suite
        i+=1
    ln=k*ln
    if call:
        return ln
    else:
        return round(ln,10)